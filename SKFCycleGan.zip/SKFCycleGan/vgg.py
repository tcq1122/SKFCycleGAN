import inspect
import os
import numpy as np
import tensorflow as tf

class Vgg19:
    def __init__(self, vgg16_npy_path=None):
        self.reuse = False
        self.name = 'vgg19'
        # if vgg16_npy_path is not None:
        #     path = inspect.getfile(Vgg19)
        #     path = os.path.abspath(os.path.join(path, os.pardir))
        #     path = os.path.join(path, "vgg19.npy")
        #     vgg16_npy_path = path
        #     print(path)

        # self.data_dict = np.load(vgg16_npy_path, encoding='latin1').item()
        # print("npy file loaded")

    def build(self, rgb):
        with tf.variable_scope(self.name):
            input =rgb * 255.0
            conv1_1 = tf.layers.conv2d(input, 64, 3, padding='same', reuse=self.reuse,kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv1_1')
            conv1_2 = tf.layers.conv2d(conv1_1, 64, 3, padding='same', reuse=self.reuse,kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv1_2')
            pool1 = tf.layers.max_pooling2d(conv1_2, 2, strides=(2,2), padding='same', name='pool1')
            #[b,w/2,h/2,64]

            conv2_1 = tf.layers.conv2d(pool1, 128, 3, padding='same', reuse=self.reuse,kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv2_1')
            conv2_2 = tf.layers.conv2d(conv2_1, 128, 3, padding='same', reuse=self.reuse,kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv2_2')
            pool2 = tf.layers.max_pooling2d(conv2_2, 2, strides=(2,2), padding='same', name='pool2')
            #[b,w/4,h/4,128]

            conv3_1 = tf.layers.conv2d(pool2, 256, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv3_1')
            conv3_2 = tf.layers.conv2d(conv3_1, 256, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv3_2')
            conv3_3 = tf.layers.conv2d(conv3_2, 256, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv3_3')
            conv3_4 = tf.layers.conv2d(conv3_3, 256, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv3_4')
            pool3 = tf.layers.max_pooling2d(conv3_4, 2, strides=(2,2), padding='same', name='pool3')
            #[b,w/8,h/8,64]

            conv4_1 = tf.layers.conv2d(pool3, 512, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv4_1')
            conv4_2 = tf.layers.conv2d(conv4_1, 512, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv4_2')
            conv4_3 = tf.layers.conv2d(conv4_2, 512, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv4_3')
            conv4_4 = tf.layers.conv2d(conv4_3, 512, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv4_4')
            pool4 = tf.layers.max_pooling2d(conv4_4, 2, strides=(2,2), padding='same', name='pool4')
            #[b,w/16,h/16,512]

            conv5_1 = tf.layers.conv2d(pool4, 512, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv5_1')
            conv5_2 = tf.layers.conv2d(conv5_1, 512, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv5_2')
            conv5_3 = tf.layers.conv2d(conv5_2, 512, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv5_3')
            conv5_4 = tf.layers.conv2d(conv5_3, 512, 3, padding='same', reuse=self.reuse, kernel_initializer=tf.contrib.layers.xavier_initializer(), activation=tf.nn.relu, name='conv5_4')
            pool5 = tf.layers.max_pooling2d(conv5_4, 2, strides=(2,2), padding='same', name='pool5')
            
        self.reuse = True
        self.variables = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope=self.name)
        
        return pool2, pool5

import tensorflow as tf
from ops import *
import utils
# from tflearn.layers.conv import global_avg_pool

class Generator:
  def __init__(self, name, is_training=True, ngf=16, norm='instance', image_size=64):
    self.name = name
    self.reuse = False
    self.ngf = ngf
    self.norm = norm
    self.is_training = is_training
    self.image_size = image_size

  def __call__(self, input):
    """
    Args:
      input: batch_size x width x height x 3
    Returns:
      output: same size as input
    """
    with tf.variable_scope(self.name):
      # conv layers
      output_unet = unet(input, name='unet', is_training=self.is_training, reuse=self.reuse)
      output_redcnn = redcnn(input, name='redcnn', reuse=self.reuse)
      output_input = tf.layers.conv2d(input, 64, 1, strides=1, padding='VALID', reuse=self.reuse,
                                kernel_initializer=tf.contrib.layers.xavier_initializer(), name='input_conv')
      # print(output_unet.shape)
      # print(output_redcnn.shape)

      sum_n = output_unet + output_redcnn + output_input
      # squeeze = global_avg_pool(sum_n)
      squeeze = tf.reduce_mean(sum_n, [1, 2], name='global_pool', keep_dims=True)

      # print(squeeze.shape)
      squeeze = tf.reshape(squeeze, [-1, 1, 1, 64])

      z = tf.layers.dense(squeeze, use_bias=True, units=64, name='d1', reuse=self.reuse)
      # print(z.shape)
      z = tf.nn.relu(z)
      a1 = tf.layers.dense(z, use_bias=True, units=64, name='d2', reuse=self.reuse)
      a2 = tf.layers.dense(z, use_bias=True, units=64, name='d3', reuse=self.reuse)
      a3 = tf.layers.dense(z, use_bias=True, units=64, name='d4', reuse=self.reuse)

      before_softmax = tf.concat([a1, a2, a3], 1)
      after_softmax = tf.nn.softmax(before_softmax, dim=1)
      # print(after_softmax.shape)

      a1 = after_softmax[:, 0, :, :]
      a1 = tf.reshape(a1, [-1, 1, 1, 64])
      a2 = after_softmax[:, 1, :, :]
      a2 = tf.reshape(a2, [-1, 1, 1, 64])
      a3 = after_softmax[:, 2, :, :]
      a3 = tf.reshape(a3, [-1, 1, 1, 64])


      select_1 = output_unet * a1
      select_2 = output_redcnn * a2
      select_3 = output_input * a3
      output = select_1 + select_2 + select_3

      output = tf.layers.conv2d(output, 1, 1, strides=1, padding='VALID', reuse=self.reuse,
                                  kernel_initializer=tf.contrib.layers.xavier_initializer(), name='conv_last')
      output = tf.nn.relu(output)

    # set reuse=True for next call
    self.reuse = True
    self.variables = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope=self.name)

    return output

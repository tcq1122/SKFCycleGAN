import tensorflow as tf
import numpy as np
import utils
from generator import Generator
import cv2
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

file_paths = [
			'1014_41.tif'
			# 'D:/zsj_CT/data/data_tif_pairs4/test/noise26.tif',
			# 'D:/zsj_CT/data/data_tif_pairs4/test/noise5.tif'
			]


batch_size = 1
checkpoints = [
			'checkpoints/20191212-2149/model.ckpt-2960000',
			# 'checkpoints/20191212-2149/model.ckpt-3340000',
			# 'checkpoints/20191212-2149/model.ckpt-3350000',
			# 'checkpoints/20191212-2149/model.ckpt-3360000',
			# 'checkpoints/20191212-2149/model.ckpt-3370000'
			]
# generator networks
X = tf.placeholder(dtype=tf.float32, shape=[batch_size, 512, 1000, 1])
is_training = tf.placeholder_with_default(True, shape=[], name='is_training')
G = Generator('G', is_training, ngf=64, norm='instance')   
Y_ = G(X)

sess = tf.Session()
saver = tf.train.Saver()
for ckpt in checkpoints:
	saver.restore(sess,ckpt)

	for file in file_paths:
		input_data = cv2.imread(file, -1)
		input_data = np.array(input_data).astype(np.float32)
		input_data = input_data / 255.0
		input_data = np.array(input_data).reshape(-1,512,1000,1)
		output_data = sess.run(Y_, feed_dict={X: input_data})

		outdata = output_data[0,:,:,0]
		outdata = outdata * 255.0
		outdata = outdata.astype(np.uint8)
		file_name = file.split('/')[-1].split('.tif')[0]
		ckpt_name = ckpt.split('-')[-1]
		cv2.imwrite('checkpoints/20191212-2149/test_amd/'+ str(file_name) +'_'+str(ckpt_name)+'.tif', outdata)
sess.close()
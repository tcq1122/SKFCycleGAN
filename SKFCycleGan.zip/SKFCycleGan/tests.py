import tensorflow as tf
import numpy as np
import utils
from generator import Generator
import cv2
import os
from scipy.io import loadmat as load
from scipy.io import savemat as save

from tensorflow.python.tools import inspect_checkpoint as chkp

# chkp.print_tensors_in_checkpoint_file('checkpoints/20200807-1648/model.ckpt-390000', tensor_name=None, all_tensors=True)

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

file_paths = [
    'F:/mingfeng/data/10ma/5mm/test/low/877_001.mat',
    'F:/mingfeng/data/10ma/5mm/test/low/877_011.mat',
    'F:/mingfeng/data/10ma/5mm/test/low/877_022.mat',
    'F:/mingfeng/data/10ma/5mm/test/low/877_033.mat',
    'F:/mingfeng/data/10ma/5mm/test/low/877_044.mat',
    'F:/mingfeng/data/10ma/5mm/test/low/877_055.mat',
]


batch_size = 1
checkpoints = [
    'checkpoints/20210325-0928/model.ckpt-890000',
]
# generator networks
X = tf.placeholder(dtype=tf.float32, shape=[batch_size, 512, 512, 1])
is_training = tf.placeholder_with_default(True, shape=[], name='is_training')
G = Generator('G', is_training, ngf=64, norm='instance')
Y_ = G(X)

sess = tf.Session()
saver = tf.train.Saver()
for ckpt in checkpoints:
    saver.restore(sess, ckpt)
    tf.reset_default_graph()


    for file in file_paths:
        input_data = load(file)['imgsave']
        input_data = np.array(input_data).astype(np.float32)
        input_data = np.array(input_data).reshape(-1, 512, 512, 1)
        output_data = sess.run(Y_, feed_dict={X: input_data})

        outdata = output_data[0, :, :, 0]
        # outdata = outdata * 255.0
        # outdata = outdata.astype(np.uint8)
        file_name = file.split('/')[-1].split('.mat')[0]
        ckpt_name = ckpt.split('-')[-1]

        save('checkpoints/20210325-0928/test/' + str(file_name) + '_' + str(ckpt_name) + '.mat', {'imgsave': outdata})

sess.close()

import tensorflow as tf
import ops

class Discriminator:
  def __init__(self, name, is_training, norm='instance'):
    self.name = name
    self.is_training = is_training
    self.norm = norm
    self.reuse = False

  def __call__(self, input):
    """
    Args:
      input: batch_size x image_size x image_size x 1
    Returns:
      output: 4D tensor batch_size x out_size x out_size x 1 (default 1x4x4x1)
              filled with 0.9 if real, 0.0 if fake
    """
    with tf.variable_scope(self.name):
      # convolution layers
      C64 = ops.Ck(input, 64, reuse=self.reuse, norm=None, stride = 1,
          is_training=self.is_training, name='C64')               # (?, w, h, 64)
      C64_1 = ops.Ck(C64, 64, reuse=self.reuse, norm=self.norm,
          is_training=self.is_training, name='C64_1')             # (?, w/2, h/2, 64)

      C128 = ops.Ck(C64_1, 128, reuse=self.reuse, norm=self.norm, stride = 1,
          is_training=self.is_training, name='C128')              # (?, w/2, h/2, 128)
      C128_1 = ops.Ck(C128, 128, reuse=self.reuse, norm=self.norm,
          is_training=self.is_training, name='C128_1')            # (?, w/4, h/4, 128)

      C256 = ops.Ck(C128_1, 256, reuse=self.reuse, norm=self.norm, stride = 1,
          is_training=self.is_training, name='C256')              # (?, w/4, h/4, 256)
      C256_1 = ops.Ck(C256, 256, reuse=self.reuse, norm=self.norm,
          is_training=self.is_training, name='C256_1')            # (?, w/8, h/8, 256)
      
      # apply a convolution to produce a 1 dimensional output (1 channel?)
      # use_sigmoid = False if use_lsgan = True
      output = ops.last_conv(C256_1, reuse=self.reuse, name='output')          # (?, w/8, h/8, 1)

    self.reuse = True
    self.variables = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope=self.name)

    return output

import cv2
from skimage.measure import compare_ssim as ssim
from skimage.measure import compare_psnr as psnr
from skimage.measure import compare_mse as mse
import numpy as np

#compare_ssim(X, Y)  计算两幅图像之间的平均结构相似性指数
#compare_psnr(im_true, im_denoise) 计算图像的峰值信噪比(PSNR)
#skimage.measure.compare_mse(im1，im2) 计算两幅图像之间的均方差


def EPI(X1, X2):
	X1 = np.asarray (X1)
	X2 = np.asarray (X2)
	X1_up = X1[:-1, :]
	X1_down = X1[1:, :]
	X2_up = X2[:-1, :]
	X2_down = X2[1:, :]
	return int (np.sum (np.abs (X1_up - X1_down))) / int (np.sum (np.abs (X2_up - X2_down)))


file_clean = 'D:/zsj_CT/data/data_tif_pairs4/test/clean5.tif'
file_cycle1 = 'checkpoints/20191109-1423/test/noise5_1510000.tif'
file_cycle2 = 'checkpoints/20191109-1423/test/noise5_1520000.tif'
file_cycle3 = 'checkpoints/20191109-1423/test/noise5_1530000.tif'
file_cycle4 = 'checkpoints/20191109-1423/test/noise5_1540000.tif'
file_cycle5 = 'checkpoints/20191109-1423/test/noise5_1550000.tif'

file_path = "checkpoints/20191109-1423/test/metric_psnr.csv"
f = open(file_path, "a+")
clean = cv2.imread(file_clean, -1)
# clean = clean[:256, 66:768+66]

file_cycles = [file_cycle1, file_cycle2, file_cycle3, file_cycle4, file_cycle5]
f.write('metrics,SSIM,PSNR,MSE,EPI')
f.write('\n')
for file in file_cycles:
	cycle = cv2.imread(file, -1)
	# cycle = cycle[:256, 66:768+66]
	file_name = file.split('/')[-1].split('.tif')[0].split('noise')[1]

	f.write('cyclegan13vgg--'+str(file_name)+','+str(ssim(clean,cycle))+','+str(psnr(clean, cycle))+','+str(mse(clean, cycle))+','+str(EPI(cycle, clean)))
	f.write('\n')

file_clean = 'D:/zsj_CT/data/data_tif_pairs4/test/clean13.tif'
file_cycle1 = 'checkpoints/20191109-1423/test/noise13_1510000.tif'
file_cycle2 = 'checkpoints/20191109-1423/test/noise13_1520000.tif'
file_cycle3 = 'checkpoints/20191109-1423/test/noise13_1530000.tif'
file_cycle4 = 'checkpoints/20191109-1423/test/noise13_1540000.tif'
file_cycle5 = 'checkpoints/20191109-1423/test/noise13_1550000.tif'

clean = cv2.imread(file_clean, -1)
# clean = clean[:256, 66:768+66]

file_cycles = [file_cycle1, file_cycle2, file_cycle3, file_cycle4, file_cycle5]
f.write('\n')
for file in file_cycles:
	cycle = cv2.imread(file, -1)
	# cycle = cycle[:256, 66:768+66]
	file_name = file.split('/')[-1].split('.tif')[0].split('noise')[1]

	f.write('cyclegan13vgg--'+str(file_name)+','+str(ssim(clean,cycle))+','+str(psnr(clean, cycle))+','+str(mse(clean, cycle))+','+str(EPI(cycle, clean)))
	f.write('\n')

file_clean = 'D:/zsj_CT/data/data_tif_pairs4/test/clean26.tif'
file_cycle1 = 'checkpoints/20191109-1423/test/noise26_1510000.tif'
file_cycle2 = 'checkpoints/20191109-1423/test/noise26_1520000.tif'
file_cycle3 = 'checkpoints/20191109-1423/test/noise26_1530000.tif'
file_cycle4 = 'checkpoints/20191109-1423/test/noise26_1540000.tif'
file_cycle5 = 'checkpoints/20191109-1423/test/noise26_1550000.tif'

clean = cv2.imread(file_clean, -1)
# clean = clean[:256, 66:768+66]

file_cycles = [file_cycle1, file_cycle2, file_cycle3, file_cycle4, file_cycle5]
f.write('\n')
for file in file_cycles:
	cycle = cv2.imread(file, -1)
	# cycle = cycle[:256, 66:768+66]
	file_name = file.split('/')[-1].split('.tif')[0].split('noise')[1]

	f.write('cyclegan13vgg--'+str(file_name)+','+str(ssim(clean,cycle))+','+str(psnr(clean, cycle))+','+str(mse(clean, cycle))+','+str(EPI(cycle, clean)))
	f.write('\n')
f.close()